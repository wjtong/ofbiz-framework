package com.banfftech.gbms.services;

import groovy.transform.Synchronized;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.ofbiz.base.util.*;
import org.apache.ofbiz.entity.Delegator;
import org.apache.ofbiz.entity.GenericEntityException;
import org.apache.ofbiz.entity.GenericValue;
import org.apache.ofbiz.entity.condition.EntityCondition;
import org.apache.ofbiz.entity.condition.EntityOperator;
import org.apache.ofbiz.entity.util.EntityQuery;
import org.apache.ofbiz.service.DispatchContext;
import org.apache.ofbiz.service.GenericServiceException;
import org.apache.ofbiz.service.LocalDispatcher;
import org.apache.ofbiz.service.ServiceUtil;
import org.apache.ofbiz.webapp.control.LoginWorker;
import org.eclipse.paho.client.mqttv3.*;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.math.BigDecimal;
import java.util.*;

/**
 * @author S
 * @description:
 * @date 2022/1/12 3:21 下午
 */
public class PointService {
    private static final long serialVersionUID = 1L;

    public static final String module = PointService.class.getName();

    // 请求路由
    private static final String topic = "/jci/services/points/req";
    // 订阅路由
    private static final String subscribeTopic = "/jci/services/points/res";
    // 质量
    private static final int qos = 1;

    private static final int total_wait = 4;

    public static String testMqttGetConnection(HttpServletRequest request, HttpServletResponse response) throws GenericEntityException, GenericServiceException {

        ServletContext servletCtx = (ServletContext) request.getAttribute("servletContext");
        MqttClient sampleClient = (MqttClient) servletCtx.getAttribute("sampleClient");
        Debug.logInfo("", "");
        return "success";
    }


    /**
     * @description: 根据传入的参数进行一次查询或者更新
     * @author: S
     * @param: contentJson
     * @createTime: 2022-02-42  5:32 下午
     */
    @Synchronized
    private static List<Map<String, Object>> sendMqttRequest(HttpServletRequest request, Delegator delegator,
                                                             JSONObject contentJson,
                                                             Map<String, Map<String, Object>> returnDatas, MqttClient sampleClient) {


        List<Map<String, Object>> returnList = new ArrayList<>();
        Debug.logInfo("int sendMqttRequest contentJson Size:" + contentJson.size(), module);
        String content = contentJson.toString();
        // 内存存储
        MemoryPersistence persistence = new MemoryPersistence();

        try {

            // 创建消息
            MqttMessage message = new MqttMessage(content.getBytes());
            // 设置消息的服务质量
            message.setQos(qos);


            // 设置回调函数
            sampleClient.setCallback(new MqttCallback() {

                public void connectionLost(Throwable cause) {
                    System.out.println("connectionLost");
                    Debug.logError("啊呀MQTT的连接断啦，正在重新连接！", module);
                    try {
                        sampleClient.reconnect();
                    } catch (MqttException e) {
                        Debug.logError("啊呀MQTT的连接断啦，而且重新连接失败!！", module);
                        Debug.logError(e.getMessage(), module);
                        e.printStackTrace();
                    }
                    Debug.logError("MQTT重连完毕!", module);
                    ServletContext servletCtx = (ServletContext) request.getAttribute("servletContext");
                    servletCtx.setAttribute("sampleClient", sampleClient);
                }

                public void messageArrived(String topic, MqttMessage message) throws Exception {

                    Debug.logInfo("messageArrived topic:" + topic, module);
                    System.out.println("Qos:" + message.getQos());
                    Debug.logInfo("messageArrived  Qos:" + message.getQos(), module);
                    System.out.println("message content:" + new String(message.getPayload()));
                    Debug.logInfo("messageArrived  content:" + new String(message.getPayload()), module);
                    JSONObject resultJson = JSONObject.fromObject(new String(message.getPayload()));
                    JSONArray messageResults = resultJson.getJSONArray("Results");
                    for (int i = 0; i < messageResults.size(); i++) {
                        JSONObject rowResult = (JSONObject) messageResults.get(i);
                        String pointId = rowResult.getString("PointId");
                        String pointValue = rowResult.get("PointValue") + "";
                        if (returnDatas == null) {
                            break;
                        }
                        Map<String, Object> dataMap = returnDatas.get(pointId);

                        // 准备进行翻译
                        String pointName = (String) dataMap.get("pointName");
                        String statusType = (String) dataMap.get("statusType");
                        if (UtilValidate.isNotEmpty(statusType)) {
                            GenericValue omtDeviceActionItem =
                                    EntityQuery.use(delegator).from("OmtDeviceActionItem").where("deviceName", pointName, "valueNumber", pointValue.substring(0, 1))
                                            .queryFirst();
                            if (null != omtDeviceActionItem) {
                                pointValue = omtDeviceActionItem.getString("valueEnglish");
                            }
                        }


                        dataMap.put("pointValue", pointValue);
                        returnList.add(dataMap);
                    }
                }

                public void deliveryComplete(IMqttDeliveryToken token) {
                    System.out.println("deliveryComplete---------" + token.isComplete());
                }

            });
            //订阅消息
            sampleClient.subscribe(subscribeTopic, qos);
            // 发布消息
            sampleClient.publish(topic, message);
            Debug.logInfo("in sendMqttRequest subscribe success!", module);
            Debug.logInfo("in sendMqttRequest publish success!", module);
            // TODO Fix me
            int wait_count = 0;
            while (returnList.size() == 0 && wait_count < total_wait) {
                try {
                    Debug.logInfo("wait call back ...", module);
                    Thread.sleep(1000);
                    wait_count += 1;
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }


            // 断开连接
//            sampleClient.disconnect();
//            Debug.logInfo("in sendMqttRequest disconnect success!", module);
            // 关闭客户端
//            sampleClient.close();
//            Debug.logInfo("in sendMqttRequest close success!", module);

            if (wait_count == total_wait) {
                throw new RuntimeException("MQTT无回调响应.");
            }
        } catch (MqttException me) {
            System.out.println("reason " + me.getReasonCode());
            System.out.println("msg " + me.getMessage());
            System.out.println("loc " + me.getLocalizedMessage());
            System.out.println("cause " + me.getCause());
            System.out.println("excep " + me);
            me.printStackTrace();
        }

//        if(returnList==null){
//            return sendMqttRequest();
//        }
        return returnList;
    }


    /**
     * @description: 根据传入的SvgId去实时查询
     * @author: S
     * @param: request
     * @param: response
     * @createTime: 2022-02-42  4:32 下午
     */
    public static String queryAdsBoundComplete(HttpServletRequest request, HttpServletResponse response) throws GenericEntityException, GenericServiceException {
        Delegator delegator = (Delegator) request.getAttribute("delegator");
        LocalDispatcher dispatcher = (LocalDispatcher) request.getAttribute("dispatcher");
        String svgId = request.getParameter("svgId");
        ServletContext servletCtx = (ServletContext) request.getAttribute("servletContext");
        MqttClient sampleClient = (MqttClient) servletCtx.getAttribute("sampleClient");
        if (UtilValidate.isEmpty(svgId)) {
            request.setAttribute("_ERROR_MESSAGE_", "svgId:" + svgId + "缺少必参数,请检查!");
            return "error";
        }
        List<GenericValue> gvList = null;
        if (UtilValidate.isNotEmpty(svgId)) {
            gvList = EntityQuery.use(delegator).from("AdsBoundComplete").where("svgId", svgId).queryList();
        } else {
            gvList = EntityQuery.use(delegator).from("AdsBoundComplete").where().queryList();
        }

        if (UtilValidate.isEmpty(gvList)) {
            request.setAttribute("_ERROR_MESSAGE_", "svgId:" + svgId + "找不到任何[AdsBoundComplete]数据.");
            return "error";
        }

        JSONObject contentJson = new JSONObject();
        contentJson.put("Response_topic", subscribeTopic);
        JSONObject payload = new JSONObject();
        payload.put("ReqType", "read");
        JSONArray reqPoints = new JSONArray();
        Map<String, Map<String, Object>> returnDatas = new HashMap<>();
        for (GenericValue rowPoint : gvList) {
            String adsId = rowPoint.getString("adsId");
            String pointLink = rowPoint.getString("pointLink");
            returnDatas.put(adsId, rowPoint.getAllFields());
            JSONObject pointRow = new JSONObject();
            pointRow.put("PointId", adsId);
            pointRow.put("PointType", "bacnet");
            pointRow.put("PointExtra", pointLink);
            reqPoints.add(pointRow);
        }


        payload.put("ReqPoints", reqPoints);
        contentJson.put("Payload", payload);
        try {
            List<Map<String, Object>> returnList = sendMqttRequest(request, delegator, contentJson, returnDatas, sampleClient);
            request.setAttribute("adsBoundComplete", returnList);
        } catch (Exception e) {
            request.setAttribute("_ERROR_MESSAGE_", "MQTT查询订阅失败,原因:" + e.getMessage());
            Debug.logError("MQTT查询订阅失败,原因:" + e.getMessage(),module);
        }

        return "success";
    }

    public static String queryAdsBoundCompleteFromDeviceCode(HttpServletRequest request, HttpServletResponse response) throws GenericEntityException, GenericServiceException {
        Delegator delegator = (Delegator) request.getAttribute("delegator");
        LocalDispatcher dispatcher = (LocalDispatcher) request.getAttribute("dispatcher");
        String storey = (String) request.getAttribute("storey");
        String tier = (String) request.getAttribute("tier");
        String deviceType = (String) request.getAttribute("deviceType");

        if (UtilValidate.isEmpty(storey) || UtilValidate.isEmpty(tier) || UtilValidate.isEmpty(deviceType)) {
            request.setAttribute("_ERROR_MESSAGE_", "storey:" + storey + ",tier:" + tier + ",deviceType:" + deviceType + "缺少必参数,请检查!");
            return "error";
        }

        ServletContext servletCtx = (ServletContext) request.getAttribute("servletContext");
        MqttClient sampleClient = (MqttClient) servletCtx.getAttribute("sampleClient");

        List<EntityCondition> conditionList = new ArrayList<>();

        if (UtilValidate.isNotEmpty(storey)) {
            conditionList.add(EntityCondition.makeCondition("storey", EntityOperator.EQUALS, storey));
        }
        if (UtilValidate.isNotEmpty(tier)) {
            conditionList.add(EntityCondition.makeCondition("tier", EntityOperator.EQUALS, tier));
        }
        if (UtilValidate.isNotEmpty(deviceType)) {
            conditionList.add(EntityCondition.makeCondition("deviceType", EntityOperator.EQUALS, deviceType));
        }


        List<GenericValue> devices = EntityQuery.use(delegator).from("DwdDevice")
                .where(conditionList).select("deviceCode").queryList();

        if (UtilValidate.isEmpty(devices)) {
            request.setAttribute("_ERROR_MESSAGE_", "storey:" + storey + ",tier:" + tier + ",deviceType:" + deviceType + "找不到任何[DwdDevice]数据.");
            return "error";
        }

        List<String> deviceCodes = new ArrayList<>();

        for (GenericValue device : devices) {
            deviceCodes.add(device.getString("deviceCode"));
        }


        List<GenericValue> adsList = EntityQuery.use(delegator).from("AdsBoundComplete")
                .where(EntityCondition.makeCondition("deviceCode", EntityOperator.IN, deviceCodes)).queryList();

        if (UtilValidate.isEmpty(adsList)) {
            request.setAttribute("_ERROR_MESSAGE_", "deviceCodes:" + deviceCodes + "找不到任何[AdsBoundComplete]数据.");
            return "error";
        }

        JSONObject contentJson = new JSONObject();
        contentJson.put("Response_topic", subscribeTopic);
        JSONObject payload = new JSONObject();
        payload.put("ReqType", "read");
        JSONArray reqPoints = new JSONArray();
        Map<String, Map<String, Object>> returnDatas = new HashMap<>();

        for (GenericValue rowPoint : adsList) {
            String adsId = rowPoint.getString("adsId");
            String pointLink = rowPoint.getString("pointLink");
            returnDatas.put(adsId, rowPoint.getAllFields());
            JSONObject pointRow = new JSONObject();
            pointRow.put("PointId", adsId);
            pointRow.put("PointType", "bacnet");
            pointRow.put("PointExtra", pointLink);
            reqPoints.add(pointRow);
        }


        payload.put("ReqPoints", reqPoints);
        contentJson.put("Payload", payload);
        try {
            List<Map<String, Object>> returnList = sendMqttRequest(request, delegator, contentJson, returnDatas, sampleClient);
            request.setAttribute("adsBoundComplete", returnList);
        } catch (Exception e) {
            request.setAttribute("_ERROR_MESSAGE_", e.getMessage());
            return "error";
        }

        return "success";
    }


    public static String updatePoints(HttpServletRequest request, HttpServletResponse response) throws GenericEntityException, GenericServiceException {
        Delegator delegator = (Delegator) request.getAttribute("delegator");
        LocalDispatcher dispatcher = (LocalDispatcher) request.getAttribute("dispatcher");
        Locale locale = UtilHttp.getLocale(request);
        Map<String, Object> data = (Map<String, Object>) request.getAttribute("data");

        ServletContext servletCtx = (ServletContext) request.getAttribute("servletContext");
        MqttClient sampleClient = (MqttClient) servletCtx.getAttribute("sampleClient");


        JSONObject pointsJson = JSONObject.fromObject(data);
        JSONArray pointArray = pointsJson.getJSONArray("points");

        JSONObject contentJson = new JSONObject();
        contentJson.put("Response_topic", "/jci/services/points/res");
        JSONObject payload = new JSONObject();
        payload.put("ReqType", "write");
        JSONArray reqPoints = new JSONArray();
        for (int i = 0; i < pointArray.size(); i++) {
            JSONObject row = (JSONObject) pointArray.get(i);
            JSONObject pointRow = new JSONObject();
            pointRow.put("PointId", row.get("pointId"));
            pointRow.put("PointType", "bacnet");
            pointRow.put("PointExtra", row.get("pointLink"));
            pointRow.put("ExpectValue", new BigDecimal(row.get("expectValue").toString()));
            reqPoints.add(pointRow);
        }
        payload.put("ReqPoints", reqPoints);
        contentJson.put("Payload", payload);


        try {
            sendMqttRequest(request, delegator, contentJson, null, sampleClient);
        } catch (Exception e) {
            request.setAttribute("_ERROR_MESSAGE_", "更新点位失败,原因:" + e.getMessage());
        }

        return "success";
    }


}
