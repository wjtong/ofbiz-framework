package com.banfftech.gbms.events;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.apache.ofbiz.base.util.Debug;
import org.apache.ofbiz.base.util.UtilValidate;
import org.apache.ofbiz.entity.Delegator;
import org.apache.ofbiz.entity.DelegatorFactory;
import org.apache.ofbiz.entity.GenericValue;
import org.apache.ofbiz.entity.util.EntityQuery;
import org.apache.ofbiz.entity.util.EntityUtilProperties;
import org.eclipse.paho.client.mqttv3.*;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import java.util.Map;

/**
 * @author S
 * @description:
 * @date 2022/2/17 6:46 下午
 */
public class MQTTInit extends org.apache.ofbiz.webapp.control.ControlServlet {


    // 请求路由
    private static final String topic = "/jci/services/points/req";
    // 订阅路由
    private static final String subscribeTopic = "/jci/services/points/res";
    // 质量
    private static final int qos = 1;

    public static final String module = MQTTInit.class.getName();

    @Override
    public void init(ServletConfig config) throws ServletException {
        Debug.logInfo("NOW IN [MQTT] INITIALS Set Up!", module);

        super.init(config);

        ServletContext context = this.getServletContext();

        String delegatorName = context.getInitParameter("entityDelegatorName");

        Delegator delegator = DelegatorFactory.getDelegator(delegatorName);

        String broker = EntityUtilProperties.getPropertyValue("platform", "mqtt.broker", delegator);
        String userName = EntityUtilProperties.getPropertyValue("platform", "mqtt.userName", delegator);
        String password = EntityUtilProperties.getPropertyValue("platform", "mqtt.password", delegator);
        String clientId = EntityUtilProperties.getPropertyValue("platform", "mqtt.clientId", delegator);

        // 内存存储
        MemoryPersistence persistence = new MemoryPersistence();

        try {
            // 创建客户端
            MqttClient sampleClient = new MqttClient(broker, clientId, persistence);
            // 创建链接参数
            MqttConnectOptions connOpts = new MqttConnectOptions();
            // 在重新启动和重新连接时记住状态
            connOpts.setCleanSession(false);
            // 设置连接的用户名
            connOpts.setUserName(userName);
            connOpts.setPassword(password.toCharArray());
            // 建立连接
            sampleClient.connect(connOpts);

            context.setAttribute("sampleClient",sampleClient);

            //订阅消息
//            sampleClient.subscribe(subscribeTopic, qos);
//            // 发布消息
//            sampleClient.publish(topic, message);
//            Debug.logInfo("in sendMqttRequest subscribe success!", module);
//            Debug.logInfo("in sendMqttRequest publish success!", module);



            // 断开连接
//            sampleClient.disconnect();
//            Debug.logInfo("in sendMqttRequest disconnect success!", module);
            // 关闭客户端
//            sampleClient.close();
//            Debug.logInfo("in sendMqttRequest close success!", module);

        } catch (MqttException me) {
            System.out.println("reason " + me.getReasonCode());
            System.out.println("msg " + me.getMessage());
            System.out.println("loc " + me.getLocalizedMessage());
            System.out.println("cause " + me.getCause());
            System.out.println("excep " + me);
            me.printStackTrace();
        }

        Debug.logInfo("MQTT CONNECTION SUCCESS~!",module);


    }




}
